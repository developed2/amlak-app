# پروژه املاک Flutter - برای Google AI Studio

## FILE: lib/data/sample_data.dart
```dart
import '../models/property.dart';

String _img(String seed) => 'https://picsum.photos/seed/$seed/800/600';

final List<Property> sampleProperties = [
  Property(
    id: 'p1',
    title: 'آپارتمان ۱۱۰ متری در سعادت‌آباد',
    city: 'تهران',
    address: 'سعادت‌آباد، بلوار دریا، پلاک ۱۲',
    price: 8500000000,
    area: 110,
    rooms: 2,
    type: PropertyType.apartment,
    deal: DealType.sale,
    description:
        'آپارتمان نورگیر با پارکینگ، انباری و آسانسور. سند تک‌برگ، آماده انتقال. آشپزخانه MDF و کف پارکت.',
    phone: '09121234567',
    images: [_img('melk1a'), _img('melk1b'), _img('melk1c')],
    lat: 35.7826,
    lng: 51.3677,
    createdAt: DateTime(2026, 10, 1),
  ),
  Property(
    id: 'p2',
    title: 'ویلا ۳۰۰ متری در کردان',
    city: 'کرج',
    address: 'کردان، خیابان ولیعصر',
    price: 15000000000,
    area: 300,
    rooms: 4,
    type: PropertyType.villa,
    deal: DealType.sale,
    description:
        'ویلای دوبلکس با استخر، حیاط بزرگ و آلاچیق. نگهبانی ۲۴ ساعته، سند شش‌دانگ.',
    phone: '09123654789',
    images: [_img('melk2a'), _img('melk2b')],
    lat: 35.9286,
    lng: 50.8276,
    createdAt: DateTime(2026, 9, 28),
  ),
  Property(
    id: 'p3',
    title: 'آپارتمان اجاره‌ای ۷۵ متری در اصفهان',
    city: 'اصفهان',
    address: 'مرداویج، خیابان آزادی',
    price: 15000000,
    area: 75,
    rooms: 2,
    type: PropertyType.apartment,
    deal: DealType.rent,
    description: 'اجاره ماهانه، رهن ۳۰۰ میلیون. طبقه دوم، بدون آسانسور ولی بسیار تمیز.',
    phone: '09131112233',
    images: [_img('melk3a'), _img('melk3b')],
    lat: 32.6225,
    lng: 51.6660,
    createdAt: DateTime(2026, 10, 5),
  ),
  Property(
    id: 'p4',
    title: 'زمین ۵۰۰ متری در شیراز',
    city: 'شیراز',
    address: 'شهرک صدرا، فاز ۲',
    price: 4200000000,
    area: 500,
    rooms: 0,
    type: PropertyType.land,
    deal: DealType.sale,
    description: 'زمین مسکونی با بر ۱۵ متر، جواز ساخت، نزدیک پارک و مدرسه.',
    phone: '09174445566',
    images: [_img('melk4a')],
    lat: 29.8103,
    lng: 52.4706,
    createdAt: DateTime(2026, 9, 20),
  ),
  Property(
    id: 'p5',
    title: 'مغازه ۴۰ متری در بازار مشهد',
    city: 'مشهد',
    address: 'بازار رضا، ورودی ۳',
    price: 25000000,
    area: 40,
    rooms: 0,
    type: PropertyType.shop,
    deal: DealType.rent,
    description: 'موقعیت عالی تجاری، پاخور بالا، مناسب پوشاک و سوغات.',
    phone: '09157778899',
    images: [_img('melk5a'), _img('melk5b')],
    lat: 36.2880,
    lng: 59.6161,
    createdAt: DateTime(2026, 10, 8),
  ),
  Property(
    id: 'p6',
    title: 'آپارتمان ۱۵۰ متری سه‌خوابه در تبریز',
    city: 'تبریز',
    address: 'ولیعصر، خیابان شریعتی',
    price: 6800000000,
    area: 150,
    rooms: 3,
    type: PropertyType.apartment,
    deal: DealType.sale,
    description: 'برج با لابی، پارکینگ اختصاصی، ویو عالی. گرمایش پکیج.',
    phone: '09141110022',
    images: [_img('melk6a'), _img('melk6b'), _img('melk6c')],
    lat: 38.0800,
    lng: 46.2900,
    createdAt: DateTime(2026, 9, 15),
  ),
  Property(
    id: 'p7',
    title: 'دفتر کار ۹۰ متری در تهران',
    city: 'تهران',
    address: 'میرداماد، برج تجاری',
    price: 30000000,
    area: 90,
    rooms: 2,
    type: PropertyType.office,
    deal: DealType.rent,
    description: 'دفتر اداری با اتاق مدیریت، سرویس فرنگی، مناسب شرکت.',
    phone: '09120001122',
    images: [_img('melk7a')],
    lat: 35.7618,
    lng: 51.4200,
    createdAt: DateTime(2026, 10, 10),
  ),
  Property(
    id: 'p8',
    title: 'ویلای ۲۰۰ متری در شمال',
    city: 'رشت',
    address: 'جاده انزلی، شهرک ساحلی',
    price: 9700000000,
    area: 200,
    rooms: 3,
    type: PropertyType.villa,
    deal: DealType.sale,
    description: 'ویلا نزدیک دریا، سنددار، مبله، حیاط با درختان میوه.',
    phone: '09113334455',
    images: [_img('melk8a'), _img('melk8b')],
    lat: 37.2808,
    lng: 49.5832,
    createdAt: DateTime(2026, 9, 25),
  ),
  Property(
    id: 'p9',
    title: 'آپارتمان ۶۵ متری نوساز در کرج',
    city: 'کرج',
    address: 'گوهردشت، خیابان اصلی',
    price: 3900000000,
    area: 65,
    rooms: 1,
    type: PropertyType.apartment,
    deal: DealType.sale,
    description: 'نوساز، کلید نخورده، پارکینگ و انباری. وام‌دار.',
    phone: '09126667788',
    images: [_img('melk9a')],
    lat: 35.8400,
    lng: 50.9391,
    createdAt: DateTime(2026, 10, 3),
  ),
  Property(
    id: 'p10',
    title: 'آپارتمان ۹۵ متری در شیراز',
    city: 'شیراز',
    address: 'معالی‌آباد، کوچه ۱۲',
    price: 12000000,
    area: 95,
    rooms: 2,
    type: PropertyType.apartment,
    deal: DealType.rent,
    description: 'اجاره با وسایل کامل، مناسب زوج جوان. طبقه سوم با آسانسور.',
    phone: '09179998877',
    images: [_img('melk10a'), _img('melk10b')],
    lat: 29.6302,
    lng: 52.5232,
    createdAt: DateTime(2026, 10, 6),
  ),
];

const List<String> allCities = [
  'همه',
  'تهران',
  'کرج',
  'اصفهان',
  'شیراز',
  'مشهد',
  'تبریز',
  'رشت',
];

```

## FILE: lib/main.dart
```dart
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'providers/app_state.dart';
import 'screens/home_screen.dart';
import 'screens/map_screen.dart';
import 'screens/add_screen.dart';
import 'screens/favorites_screen.dart';
import 'utils/format.dart';

void main() {
  runApp(const AmlakApp());
}

class AmlakApp extends StatelessWidget {
  const AmlakApp({super.key});

  @override
  Widget build(BuildContext context) {
    return ChangeNotifierProvider(
      create: (_) => AppState()..load(),
      child: MaterialApp(
        title: 'املاک',
        debugShowCheckedModeBanner: false,
        locale: const Locale('fa', 'IR'),
        supportedLocales: const [Locale('fa', 'IR')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: ThemeData(
          useMaterial3: true,
          colorSchemeSeed: const Color(0xFF1565C0),
          fontFamily: null,
        ),
        home: const MainShell(),
        routes: {
          '/map': (_) => Scaffold(
                appBar: AppBar(title: const Text('نقشه')),
                body: const MapScreen(),
              )
        },
      ),
    );
  }
}

class MainShell extends StatefulWidget {
  const MainShell({super.key});

  @override
  State<MainShell> createState() => _MainShellState();
}

class _MainShellState extends State<MainShell> {
  int index = 0;

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final favCount = app.favorites.length;
    final pages = [
      const HomeScreen(),
      const MapScreen(),
      AddScreen(onSaved: () => setState(() => index = 0)),
      const FavoritesScreen(),
    ];
    final titles = ['املاک', 'نقشه', 'ثبت آگهی', 'علاقه‌مندی‌ها'];
    return Directionality(
      textDirection: TextDirection.rtl,
      child: Scaffold(
        appBar: AppBar(
          title: Text(titles[index]),
          centerTitle: true,
          actions: [
            if (index == 0)
              IconButton(
                icon: const Icon(Icons.refresh),
                tooltip: 'حذف فیلترها',
                onPressed: app.clearFilters,
              ),
          ],
        ),
        body: IndexedStack(index: index, children: pages),
        bottomNavigationBar: NavigationBar(
          selectedIndex: index,
          onDestinationSelected: (i) => setState(() => index = i),
          destinations: [
            const NavigationDestination(
                icon: Icon(Icons.home_outlined),
                selectedIcon: Icon(Icons.home),
                label: 'خانه'),
            const NavigationDestination(
                icon: Icon(Icons.map_outlined),
                selectedIcon: Icon(Icons.map),
                label: 'نقشه'),
            const NavigationDestination(
                icon: Icon(Icons.add_circle_outline),
                selectedIcon: Icon(Icons.add_circle),
                label: 'ثبت آگهی'),
            NavigationDestination(
              icon: Badge(
                isLabelVisible: favCount > 0,
                label: Text(toFaDigits(favCount.toString())),
                child: const Icon(Icons.favorite_border),
              ),
              selectedIcon: Badge(
                isLabelVisible: favCount > 0,
                label: Text(toFaDigits(favCount.toString())),
                child: const Icon(Icons.favorite),
              ),
              label: 'علاقه‌مندی‌ها',
            ),
          ],
        ),
      ),
    );
  }
}

```

## FILE: lib/models/property.dart
```dart
import 'dart:convert';

enum PropertyType { apartment, villa, land, shop, office }

enum DealType { sale, rent }

String propertyTypeLabel(PropertyType t) {
  switch (t) {
    case PropertyType.apartment:
      return 'آپارتمان';
    case PropertyType.villa:
      return 'ویلا';
    case PropertyType.land:
      return 'زمین';
    case PropertyType.shop:
      return 'مغازه';
    case PropertyType.office:
      return 'دفتر کار';
  }
}

String dealLabel(DealType d) {
  switch (d) {
    case DealType.sale:
      return 'فروش';
    case DealType.rent:
      return 'اجاره';
  }
}

PropertyType propertyTypeFromString(String s) {
  return PropertyType.values.firstWhere(
    (e) => e.name == s,
    orElse: () => PropertyType.apartment,
  );
}

DealType dealFromString(String s) {
  return DealType.values.firstWhere(
    (e) => e.name == s,
    orElse: () => DealType.sale,
  );
}

class Property {
  final String id;
  final String title;
  final String city;
  final String address;
  final int price; // تومان (برای اجاره: ماهانه)
  final int area; // متر مربع
  final int rooms;
  final PropertyType type;
  final DealType deal;
  final String description;
  final String phone;
  final List<String> images;
  final double lat;
  final double lng;
  final DateTime createdAt;
  final bool isUserAdded;

  const Property({
    required this.id,
    required this.title,
    required this.city,
    required this.address,
    required this.price,
    required this.area,
    required this.rooms,
    required this.type,
    required this.deal,
    required this.description,
    required this.phone,
    required this.images,
    required this.lat,
    required this.lng,
    required this.createdAt,
    this.isUserAdded = false,
  });

  Map<String, dynamic> toJson() => {
        'id': id,
        'title': title,
        'city': city,
        'address': address,
        'price': price,
        'area': area,
        'rooms': rooms,
        'type': type.name,
        'deal': deal.name,
        'description': description,
        'phone': phone,
        'images': images,
        'lat': lat,
        'lng': lng,
        'createdAt': createdAt.toIso8601String(),
        'isUserAdded': isUserAdded,
      };

  factory Property.fromJson(Map<String, dynamic> j) => Property(
        id: j['id'] as String,
        title: j['title'] as String,
        city: j['city'] as String,
        address: j['address'] as String,
        price: (j['price'] as num).toInt(),
        area: (j['area'] as num).toInt(),
        rooms: (j['rooms'] as num).toInt(),
        type: propertyTypeFromString(j['type'] as String),
        deal: dealFromString(j['deal'] as String),
        description: j['description'] as String? ?? '',
        phone: j['phone'] as String? ?? '',
        images: (j['images'] as List? ?? []).map((e) => e.toString()).toList(),
        lat: (j['lat'] as num).toDouble(),
        lng: (j['lng'] as num).toDouble(),
        createdAt: DateTime.tryParse(j['createdAt'] as String? ?? '') ??
            DateTime.now(),
        isUserAdded: j['isUserAdded'] as bool? ?? false,
      );

  static String encodeList(List<Property> list) =>
      jsonEncode(list.map((e) => e.toJson()).toList());

  static List<Property> decodeList(String raw) {
    final arr = jsonDecode(raw) as List;
    return arr.map((e) => Property.fromJson(e as Map<String, dynamic>)).toList();
  }
}

```

## FILE: lib/providers/app_state.dart
```dart
import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';
import '../models/property.dart';
import '../data/sample_data.dart';

class AppState extends ChangeNotifier {
  List<Property> _custom = [];
  final Set<String> _favorites = {};

  String searchQuery = '';
  String selectedCity = 'همه';
  DealType? selectedDeal;
  PropertyType? selectedType;
  int? minArea;
  int? maxPrice;

  bool _loaded = false;
  bool get loaded => _loaded;

  List<Property> get all => [..._custom, ...sampleProperties];

  Set<String> get favorites => _favorites;

  List<Property> get filtered {
    final q = searchQuery.trim();
    return all.where((p) {
      if (selectedCity != 'همه' && p.city != selectedCity) return false;
      if (selectedDeal != null && p.deal != selectedDeal) return false;
      if (selectedType != null && p.type != selectedType) return false;
      if (minArea != null && p.area < minArea!) return false;
      if (maxPrice != null && p.price > maxPrice!) return false;
      if (q.isNotEmpty) {
        final hay = '${p.title} ${p.city} ${p.address} ${p.description}';
        if (!hay.contains(q)) return false;
      }
      return true;
    }).toList();
  }

  List<Property> get favoriteItems =>
      all.where((p) => _favorites.contains(p.id)).toList();

  bool isFav(String id) => _favorites.contains(id);

  Future<void> load() async {
    if (_loaded) return;
    try {
      final sp = await SharedPreferences.getInstance();
      final rawCustom = sp.getString('custom_props');
      if (rawCustom != null && rawCustom.isNotEmpty) {
        _custom = Property.decodeList(rawCustom);
      }
      final favs = sp.getStringList('favs') ?? [];
      _favorites.addAll(favs);
    } catch (_) {
      // اگر خطا داد، با داده نمونه ادامه بده
    }
    _loaded = true;
    notifyListeners();
  }

  Future<void> _saveCustom() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setString('custom_props', Property.encodeList(_custom));
  }

  Future<void> _saveFavs() async {
    final sp = await SharedPreferences.getInstance();
    await sp.setStringList('favs', _favorites.toList());
  }

  Future<void> addProperty(Property p) async {
    _custom.insert(0, p);
    notifyListeners();
    await _saveCustom();
  }

  Future<void> removeProperty(String id) async {
    _custom.removeWhere((e) => e.id == id);
    _favorites.remove(id);
    notifyListeners();
    await _saveCustom();
    await _saveFavs();
  }

  Future<void> toggleFav(String id) async {
    if (_favorites.contains(id)) {
      _favorites.remove(id);
    } else {
      _favorites.add(id);
    }
    notifyListeners();
    await _saveFavs();
  }

  void setSearch(String v) {
    searchQuery = v;
    notifyListeners();
  }

  void setCity(String v) {
    selectedCity = v;
    notifyListeners();
  }

  void setFilters({DealType? deal, PropertyType? type, int? minAreaP, int? maxPriceP}) {
    selectedDeal = deal;
    selectedType = type;
    minArea = minAreaP;
    maxPrice = maxPriceP;
    notifyListeners();
  }

  void clearFilters() {
    selectedDeal = null;
    selectedType = null;
    minArea = null;
    maxPrice = null;
    selectedCity = 'همه';
    searchQuery = '';
    notifyListeners();
  }

  Property? byId(String id) {
    try {
      return all.firstWhere((e) => e.id == id);
    } catch (_) {
      return null;
    }
  }
}

```

## FILE: lib/screens/add_screen.dart
```dart
import 'package:flutter/material.dart';
import 'package:image_picker/image_picker.dart';
import 'package:provider/provider.dart';
import '../models/property.dart';
import '../providers/app_state.dart';
import '../data/sample_data.dart';

class AddScreen extends StatefulWidget {
  final VoidCallback? onSaved;
  const AddScreen({super.key, this.onSaved});

  @override
  State<AddScreen> createState() => _AddScreenState();
}

class _AddScreenState extends State<AddScreen> {
  final _form = GlobalKey<FormState>();
  final titleCtrl = TextEditingController();
  final addressCtrl = TextEditingController();
  final priceCtrl = TextEditingController();
  final areaCtrl = TextEditingController();
  final roomsCtrl = TextEditingController(text: '2');
  final descCtrl = TextEditingController();
  final phoneCtrl = TextEditingController();
  final imgUrlCtrl = TextEditingController();

  String city = 'تهران';
  DealType deal = DealType.sale;
  PropertyType type = PropertyType.apartment;
  final List<String> localImages = [];

  @override
  void dispose() {
    titleCtrl.dispose();
    addressCtrl.dispose();
    priceCtrl.dispose();
    areaCtrl.dispose();
    roomsCtrl.dispose();
    descCtrl.dispose();
    phoneCtrl.dispose();
    imgUrlCtrl.dispose();
    super.dispose();
  }

  Future<void> _pickImage() async {
    final picker = ImagePicker();
    final x = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80);
    if (x != null) setState(() => localImages.add(x.path));
  }

  Future<void> _save() async {
    if (!_form.currentState!.validate()) return;
    final images = <String>[
      ...localImages,
      if (imgUrlCtrl.text.trim().isNotEmpty) imgUrlCtrl.text.trim(),
    ];
    if (images.isEmpty) {
      images.add('https://picsum.photos/seed/${DateTime.now().millisecondsSinceEpoch}/800/600');
    }
    final p = Property(
      id: 'u${DateTime.now().millisecondsSinceEpoch}',
      title: titleCtrl.text.trim(),
      city: city,
      address: addressCtrl.text.trim(),
      price: int.parse(priceCtrl.text.trim()),
      area: int.parse(areaCtrl.text.trim()),
      rooms: int.tryParse(roomsCtrl.text.trim()) ?? 0,
      type: type,
      deal: deal,
      description: descCtrl.text.trim(),
      phone: phoneCtrl.text.trim(),
      images: images,
      lat: 35.6892,
      lng: 51.3890,
      createdAt: DateTime.now(),
      isUserAdded: true,
    );
    await Provider.of<AppState>(context, listen: false).addProperty(p);
    if (!mounted) return;
    ScaffoldMessenger.of(context).showSnackBar(
      const SnackBar(content: Text('آگهی با موفقیت ثبت شد')),
    );
    _form.currentState!.reset();
    titleCtrl.clear();
    addressCtrl.clear();
    priceCtrl.clear();
    areaCtrl.clear();
    descCtrl.clear();
    phoneCtrl.clear();
    imgUrlCtrl.clear();
    setState(() => localImages.clear());
    widget.onSaved?.call();
  }

  @override
  Widget build(BuildContext context) {
    return Form(
      key: _form,
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          const Text('ثبت آگهی جدید',
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          const SizedBox(height: 12),
          TextFormField(
            controller: titleCtrl,
            decoration: const InputDecoration(
                labelText: 'عنوان آگهی *', border: OutlineInputBorder()),
            validator: (v) =>
                (v == null || v.trim().length < 5) ? 'عنوان کوتاه است' : null,
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: DropdownButtonFormField<String>(
                  value: city,
                  decoration: const InputDecoration(
                      labelText: 'شهر', border: OutlineInputBorder()),
                  items: [
                    for (final c in allCities.where((e) => e != 'همه'))
                      DropdownMenuItem(value: c, child: Text(c)),
                  ],
                  onChanged: (v) => setState(() => city = v ?? city),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: DropdownButtonFormField<DealType>(
                  value: deal,
                  decoration: const InputDecoration(
                      labelText: 'معامله', border: OutlineInputBorder()),
                  items: const [
                    DropdownMenuItem(
                        value: DealType.sale, child: Text('فروش')),
                    DropdownMenuItem(
                        value: DealType.rent, child: Text('اجاره')),
                  ],
                  onChanged: (v) => setState(() => deal = v ?? deal),
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          DropdownButtonFormField<PropertyType>(
            value: type,
            decoration: const InputDecoration(
                labelText: 'نوع ملک', border: OutlineInputBorder()),
            items: [
              for (final t in PropertyType.values)
                DropdownMenuItem(
                    value: t, child: Text(propertyTypeLabel(t))),
            ],
            onChanged: (v) => setState(() => type = v ?? type),
          ),
          const SizedBox(height: 10),
          TextFormField(
            controller: addressCtrl,
            decoration: const InputDecoration(
                labelText: 'آدرس *', border: OutlineInputBorder()),
            validator: (v) =>
                (v == null || v.trim().isEmpty) ? 'آدرس لازم است' : null,
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: priceCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'قیمت (تومان) *',
                      border: OutlineInputBorder()),
                  validator: (v) => (int.tryParse((v ?? '').trim()) == null)
                      ? 'عدد معتبر وارد کنید'
                      : null,
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextFormField(
                  controller: areaCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'متراژ *', border: OutlineInputBorder()),
                  validator: (v) => (int.tryParse((v ?? '').trim()) == null)
                      ? 'عدد معتبر وارد کنید'
                      : null,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          Row(
            children: [
              Expanded(
                child: TextFormField(
                  controller: roomsCtrl,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(
                      labelText: 'تعداد خواب', border: OutlineInputBorder()),
                ),
              ),
              const SizedBox(width: 8),
              Expanded(
                child: TextFormField(
                  controller: phoneCtrl,
                  keyboardType: TextInputType.phone,
                  decoration: const InputDecoration(
                      labelText: 'موبایل مالک *',
                      hintText: '0912...',
                      border: OutlineInputBorder()),
                  validator: (v) => ((v ?? '').trim().length < 10)
                      ? 'شماره معتبر نیست'
                      : null,
                ),
              ),
            ],
          ),
          const SizedBox(height: 10),
          TextFormField(
            controller: descCtrl,
            maxLines: 3,
            decoration: const InputDecoration(
                labelText: 'توضیحات', border: OutlineInputBorder()),
          ),
          const SizedBox(height: 10),
          TextFormField(
            controller: imgUrlCtrl,
            decoration: const InputDecoration(
                labelText: 'لینک عکس (اختیاری)',
                hintText: 'https://...',
                border: OutlineInputBorder()),
          ),
          const SizedBox(height: 8),
          OutlinedButton.icon(
            icon: const Icon(Icons.image_outlined),
            label: Text(localImages.isEmpty
                ? 'انتخاب عکس از گالری'
                : '${localImages.length} عکس انتخاب شد + افزودن'),
            onPressed: _pickImage,
          ),
          const SizedBox(height: 12),
          ElevatedButton.icon(
            icon: const Icon(Icons.check),
            label: const Text('ثبت آگهی'),
            onPressed: _save,
          ),
          const SizedBox(height: 30),
        ],
      ),
    );
  }
}

```

## FILE: lib/screens/detail_screen.dart
```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import 'package:url_launcher/url_launcher.dart';
import '../providers/app_state.dart';
import '../models/property.dart';
import '../utils/format.dart';
import '../widgets/property_card.dart';

class DetailScreen extends StatelessWidget {
  final String propertyId;
  const DetailScreen({super.key, required this.propertyId});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final p = app.byId(propertyId);
    if (p == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('جزئیات')),
        body: const Center(child: Text('این آگهی حذف شده است')),
      );
    }
    final fav = app.isFav(p.id);
    return Scaffold(
      appBar: AppBar(
        title: Text(p.title, overflow: TextOverflow.ellipsis),
        actions: [
          IconButton(
            icon: Icon(fav ? Icons.favorite : Icons.favorite_border,
                color: fav ? Colors.red : null),
            onPressed: () => app.toggleFav(p.id),
          ),
          if (p.isUserAdded)
            IconButton(
              icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                final ok = await showDialog<bool>(
                  context: context,
                  builder: (_) => AlertDialog(
                    title: const Text('حذف آگهی؟'),
                    content: const Text('این آگهی برای همیشه حذف می‌شود.'),
                    actions: [
                      TextButton(
                          onPressed: () => Navigator.pop(context, false),
                          child: const Text('انصراف')),
                      ElevatedButton(
                          onPressed: () => Navigator.pop(context, true),
                          child: const Text('حذف')),
                    ],
                  ),
                );
                if (ok == true && context.mounted) {
                  await app.removeProperty(p.id);
                  if (context.mounted) Navigator.pop(context);
                }
              },
            ),
        ],
      ),
      bottomNavigationBar: SafeArea(
        child: Padding(
          padding: const EdgeInsets.all(12),
          child: Row(
            children: [
              Expanded(
                child: ElevatedButton.icon(
                  icon: const Icon(Icons.phone),
                  label: Text('تماس: ${toFaDigits(p.phone)}'),
                  onPressed: () async {
                    final uri = Uri.parse('tel:${p.phone}');
                    if (await canLaunchUrl(uri)) {
                      await launchUrl(uri);
                    } else if (context.mounted) {
                      ScaffoldMessenger.of(context).showSnackBar(
                        const SnackBar(
                            content: Text('امکان تماس وجود ندارد')),
                      );
                    }
                  },
                ),
              ),
            ],
          ),
        ),
      ),
      body: SingleChildScrollView(
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            if (p.images.isNotEmpty)
              SizedBox(
                height: 260,
                child: PageView.builder(
                  itemCount: p.images.length,
                  itemBuilder: (_, i) => propertyImage(p.images[i]),
                ),
              )
            else
              Container(
                height: 200,
                color: Colors.grey.shade200,
                child: const Icon(Icons.home, size: 80),
              ),
            Padding(
              padding: const EdgeInsets.all(16),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Row(
                    children: [
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: p.deal == DealType.sale
                              ? Colors.green.shade100
                              : Colors.orange.shade100,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(dealLabel(p.deal)),
                      ),
                      const SizedBox(width: 8),
                      Container(
                        padding: const EdgeInsets.symmetric(
                            horizontal: 10, vertical: 4),
                        decoration: BoxDecoration(
                          color: Colors.blue.shade50,
                          borderRadius: BorderRadius.circular(20),
                        ),
                        child: Text(propertyTypeLabel(p.type)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(p.title,
                      style: const TextStyle(
                          fontSize: 18, fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.location_on_outlined,
                          size: 16, color: Colors.grey),
                      Expanded(
                        child: Text('${p.city} ـ ${p.address}',
                            style:
                                const TextStyle(color: Colors.grey)),
                      ),
                    ],
                  ),
                  const SizedBox(height: 12),
                  Text(formatPriceFa(p.price),
                      style: TextStyle(
                          fontSize: 20,
                          fontWeight: FontWeight.bold,
                          color: Theme.of(context).primaryColor)),
                  const Divider(height: 24),
                  Row(
                    mainAxisAlignment: MainAxisAlignment.spaceAround,
                    children: [
                      _info(Icons.square_foot, formatAreaFa(p.area)),
                      _info(Icons.bed_outlined,
                          '${toFaDigits(p.rooms.toString())} خوابه'),
                      _info(Icons.location_city_outlined, p.city),
                    ],
                  ),
                  const Divider(height: 24),
                  const Text('توضیحات',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 6),
                  Text(p.description),
                  const SizedBox(height: 16),
                  const Text('موقعیت تقریبی',
                      style: TextStyle(fontWeight: FontWeight.bold)),
                  const SizedBox(height: 4),
                  Text(
                      'عرض جغرافیایی ${toFaDigits(p.lat.toString())} ـ طول جغرافیایی ${toFaDigits(p.lng.toString())}',
                      style: const TextStyle(
                          color: Colors.grey, fontSize: 12)),
                  const SizedBox(height: 6),
                  OutlinedButton.icon(
                    icon: const Icon(Icons.map_outlined),
                    label: const Text('نمایش روی نقشه'),
                    onPressed: () =>
                        Navigator.popAndPushNamed(context, '/map'),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _info(IconData icon, String text) {
    return Column(
      children: [
        Icon(icon, color: Colors.blueGrey),
        const SizedBox(height: 4),
        Text(text, style: const TextStyle(fontSize: 12)),
      ],
    );
  }
}

```

## FILE: lib/screens/favorites_screen.dart
```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../widgets/property_card.dart';

class FavoritesScreen extends StatelessWidget {
  const FavoritesScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final favs = context.watch<AppState>().favoriteItems;
    if (favs.isEmpty) {
      return const Center(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          children: [
            Icon(Icons.favorite_border, size: 64, color: Colors.grey),
            SizedBox(height: 8),
            Text('هنوز ملکی را ذخیره نکرده‌اید'),
            Text('روی قلب هر آگهی بزنید', style: TextStyle(color: Colors.grey)),
          ],
        ),
      );
    }
    return ListView.builder(
      padding: const EdgeInsets.only(top: 8, bottom: 8),
      itemCount: favs.length,
      itemBuilder: (_, i) => PropertyCard(property: favs[i]),
    );
  }
}

```

## FILE: lib/screens/home_screen.dart
```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../data/sample_data.dart';
import '../widgets/property_card.dart';
import '../widgets/filter_sheet.dart';
import '../utils/format.dart';

class HomeScreen extends StatefulWidget {
  const HomeScreen({super.key});

  @override
  State<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final _searchCtrl = TextEditingController();

  @override
  void dispose() {
    _searchCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    if (_searchCtrl.text != app.searchQuery) {
      _searchCtrl.value = TextEditingValue(
        text: app.searchQuery,
        selection: TextSelection.collapsed(offset: app.searchQuery.length),
      );
    }
    final list = app.filtered;
    return Column(
      children: [
        Padding(
          padding: const EdgeInsets.fromLTRB(12, 12, 12, 4),
          child: TextField(
            controller: _searchCtrl,
            onChanged: app.setSearch,
            decoration: InputDecoration(
              hintText: 'جستجو: نام، شهر، آدرس...',
              prefixIcon: const Icon(Icons.search),
              suffixIcon: app.searchQuery.isNotEmpty
                  ? IconButton(
                      icon: const Icon(Icons.clear),
                      onPressed: () => app.setSearch(''),
                    )
                  : IconButton(
                      icon: const Icon(Icons.tune),
                      onPressed: () => showModalBottomSheet(
                        context: context,
                        isScrollControlled: true,
                        shape: const RoundedRectangleBorder(
                          borderRadius:
                              BorderRadius.vertical(top: Radius.circular(18)),
                        ),
                        builder: (_) => const FilterSheet(),
                      ),
                    ),
              border: OutlineInputBorder(
                  borderRadius: BorderRadius.circular(14)),
              filled: true,
              fillColor: Colors.white,
            ),
          ),
        ),
        SizedBox(
          height: 44,
          child: ListView(
            scrollDirection: Axis.horizontal,
            padding: const EdgeInsets.symmetric(horizontal: 12),
            children: [
              for (final c in allCities)
                Padding(
                  padding: const EdgeInsets.only(left: 6),
                  child: ChoiceChip(
                    label: Text(c),
                    selected: app.selectedCity == c,
                    onSelected: (_) => app.setCity(c),
                  ),
                ),
              Padding(
                padding: const EdgeInsets.only(left: 6),
                child: ActionChip(
                  avatar: const Icon(Icons.tune, size: 16),
                  label: const Text('فیلتر'),
                  onPressed: () => showModalBottomSheet(
                    context: context,
                    isScrollControlled: true,
                    shape: const RoundedRectangleBorder(
                      borderRadius:
                          BorderRadius.vertical(top: Radius.circular(18)),
                    ),
                    builder: (_) => const FilterSheet(),
                  ),
                ),
              ),
            ],
          ),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 14, vertical: 4),
          child: Row(
            children: [
              Text('${toFaDigits(list.length.toString())} آگهی پیدا شد',
                  style: const TextStyle(color: Colors.grey)),
              const Spacer(),
              if (app.selectedDeal != null ||
                  app.selectedType != null ||
                  app.minArea != null ||
                  app.maxPrice != null)
                TextButton(
                  onPressed: app.clearFilters,
                  child: const Text('حذف فیلترها'),
                ),
            ],
          ),
        ),
        Expanded(
          child: list.isEmpty
              ? Center(
                  child: Column(
                    mainAxisSize: MainAxisSize.min,
                    children: [
                      const Icon(Icons.search_off,
                          size: 64, color: Colors.grey),
                      const SizedBox(height: 8),
                      const Text('ملکی پیدا نشد'),
                      TextButton(
                        onPressed: app.clearFilters,
                        child: const Text('حذف فیلترها'),
                      ),
                    ],
                  ),
                )
              : ListView.builder(
                  itemCount: list.length,
                  itemBuilder: (_, i) => PropertyCard(property: list[i]),
                ),
        ),
      ],
    );
  }
}

```

## FILE: lib/screens/map_screen.dart
```dart
import 'package:flutter/material.dart';
import 'package:flutter_map/flutter_map.dart';
import 'package:latlong2/latlong.dart';
import 'package:provider/provider.dart';
import '../providers/app_state.dart';
import '../screens/detail_screen.dart';

class MapScreen extends StatelessWidget {
  const MapScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final list = app.filtered;
    final center = list.isNotEmpty
        ? LatLng(list.first.lat, list.first.lng)
        : const LatLng(35.6892, 51.3890);
    return FlutterMap(
      options: MapOptions(
        initialCenter: center,
        initialZoom: list.isNotEmpty ? 11 : 6,
      ),
      children: [
        TileLayer(
          urlTemplate: 'https://tile.openstreetmap.org/{z}/{x}/{y}.png',
          userAgentPackageName: 'com.example.amlak_app',
        ),
        MarkerLayer(
          markers: [
            for (final p in list)
              Marker(
                point: LatLng(p.lat, p.lng),
                width: 44,
                height: 44,
                child: GestureDetector(
                  onTap: () {
                    showModalBottomSheet(
                      context: context,
                      builder: (_) => ListTile(
                        title: Text(p.title,
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        subtitle: Text('${p.city} ـ ${p.address}',
                            maxLines: 1, overflow: TextOverflow.ellipsis),
                        trailing: const Icon(Icons.arrow_forward),
                        onTap: () {
                          Navigator.pop(context);
                          Navigator.push(
                            context,
                            MaterialPageRoute(
                              builder: (_) =>
                                  DetailScreen(propertyId: p.id),
                            ),
                          );
                        },
                      ),
                    );
                  },
                  child: const Icon(Icons.location_pin,
                      size: 40, color: Colors.red),
                ),
              ),
          ],
        ),
        Positioned(
          left: 12,
          bottom: 12,
          child: Container(
            padding:
                const EdgeInsets.symmetric(horizontal: 10, vertical: 6),
            decoration: BoxDecoration(
              color: Colors.white,
              borderRadius: BorderRadius.circular(10),
              boxShadow: const [BoxShadow(blurRadius: 6, color: Colors.black26)],
            ),
            child: Text('${list.length} ملک روی نقشه',
                style: const TextStyle(fontSize: 12)),
          ),
        ),
      ],
    );
  }
}

```

## FILE: lib/utils/format.dart
```dart
// ابزارهای فارسی‌سازی اعداد و قیمت
String toFaDigits(String input) {
  const en = ['0', '1', '2', '3', '4', '5', '6', '7', '8', '9'];
  const fa = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];
  var out = input;
  for (var i = 0; i < 10; i++) {
    out = out.replaceAll(en[i], fa[i]);
  }
  return out;
}

/// 3500000000 -> ۳٬۵۰۰٬۰۰۰٬۰۰۰ تومان
String formatPriceFa(int price) {
  final s = price.toString();
  final buf = StringBuffer();
  int count = 0;
  for (int i = s.length - 1; i >= 0; i--) {
    buf.write(s[i]);
    count++;
    if (count % 3 == 0 && i != 0) buf.write('٬');
  }
  final reversed = buf.toString().split('').reversed.join();
  return '${toFaDigits(reversed)} تومان';
}

String formatAreaFa(int area) => '${toFaDigits(area.toString())} متر';

```

## FILE: lib/widgets/filter_sheet.dart
```dart
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/property.dart';
import '../providers/app_state.dart';
import '../utils/format.dart';

class FilterSheet extends StatefulWidget {
  const FilterSheet({super.key});

  @override
  State<FilterSheet> createState() => _FilterSheetState();
}

class _FilterSheetState extends State<FilterSheet> {
  DealType? deal;
  PropertyType? type;
  final minAreaCtrl = TextEditingController();
  final maxPriceCtrl = TextEditingController();

  @override
  void initState() {
    super.initState();
    final app = Provider.of<AppState>(context, listen: false);
    deal = app.selectedDeal;
    type = app.selectedType;
    if (app.minArea != null) minAreaCtrl.text = app.minArea.toString();
    if (app.maxPrice != null) maxPriceCtrl.text = app.maxPrice.toString();
  }

  @override
  void dispose() {
    minAreaCtrl.dispose();
    maxPriceCtrl.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        bottom: MediaQuery.of(context).viewInsets.bottom,
        right: 16,
        left: 16,
        top: 16,
      ),
      child: SingleChildScrollView(
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            const Text('فیلتر جستجو',
                style: TextStyle(fontWeight: FontWeight.bold, fontSize: 17)),
            const SizedBox(height: 12),
            const Text('نوع معامله'),
            Wrap(
              spacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('همه'),
                  selected: deal == null,
                  onSelected: (_) => setState(() => deal = null),
                ),
                ChoiceChip(
                  label: const Text('فروش'),
                  selected: deal == DealType.sale,
                  onSelected: (_) =>
                      setState(() => deal = DealType.sale),
                ),
                ChoiceChip(
                  label: const Text('اجاره'),
                  selected: deal == DealType.rent,
                  onSelected: (_) =>
                      setState(() => deal = DealType.rent),
                ),
              ],
            ),
            const SizedBox(height: 8),
            const Text('نوع ملک'),
            Wrap(
              spacing: 8,
              children: [
                ChoiceChip(
                  label: const Text('همه'),
                  selected: type == null,
                  onSelected: (_) => setState(() => type = null),
                ),
                for (final t in PropertyType.values)
                  ChoiceChip(
                    label: Text(propertyTypeLabel(t)),
                    selected: type == t,
                    onSelected: (_) => setState(() => type = t),
                  ),
              ],
            ),
            const SizedBox(height: 8),
            TextField(
              controller: minAreaCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'حداقل متراژ (متر)',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 8),
            TextField(
              controller: maxPriceCtrl,
              keyboardType: TextInputType.number,
              decoration: const InputDecoration(
                labelText: 'حداکثر قیمت (تومان)',
                hintText: 'مثلا 5000000000',
                border: OutlineInputBorder(),
              ),
            ),
            const SizedBox(height: 12),
            Row(
              children: [
                Expanded(
                  child: OutlinedButton(
                    onPressed: () {
                      Provider.of<AppState>(context, listen: false)
                          .clearFilters();
                      Navigator.pop(context);
                    },
                    child: const Text('حذف فیلتر'),
                  ),
                ),
                const SizedBox(width: 8),
                Expanded(
                  child: ElevatedButton(
                    onPressed: () {
                      final minA = int.tryParse(minAreaCtrl.text.trim());
                      final maxP = int.tryParse(maxPriceCtrl.text.trim());
                      Provider.of<AppState>(context, listen: false).setFilters(
                        deal: deal,
                        type: type,
                        minAreaP: minA,
                        maxPriceP: maxP,
                      );
                      Navigator.pop(context);
                    },
                    child: const Text('اعمال فیلتر'),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 16),
          ],
        ),
      ),
    );
  }
}

```

## FILE: lib/widgets/property_card.dart
```dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../models/property.dart';
import '../providers/app_state.dart';
import '../utils/format.dart';
import '../screens/detail_screen.dart';

Widget propertyImage(String url, {double? height, BoxFit fit = BoxFit.cover}) {
  if (url.startsWith('/') || url.startsWith('file:')) {
    final path = url.startsWith('file:') ? Uri.parse(url).path : url;
    final f = File(path);
    if (f.existsSync()) {
      return Image.file(f, height: height, width: double.infinity, fit: fit);
    }
  }
  return Image.network(
    url,
    height: height,
    width: double.infinity,
    fit: fit,
    errorBuilder: (_, __, ___) => Container(
      height: height ?? 180,
      color: Colors.grey.shade200,
      child: const Icon(Icons.home_work_outlined, size: 64, color: Colors.grey),
    ),
    loadingBuilder: (c, w, p) {
      if (p == null) return w;
      return Container(
        height: height ?? 180,
        alignment: Alignment.center,
        child: const CircularProgressIndicator(),
      );
    },
  );
}

class PropertyCard extends StatelessWidget {
  final Property property;
  const PropertyCard({super.key, required this.property});

  @override
  Widget build(BuildContext context) {
    final app = context.watch<AppState>();
    final fav = app.isFav(property.id);
    final img = property.images.isNotEmpty ? property.images.first : '';
    return Card(
      elevation: 2,
      margin: const EdgeInsets.symmetric(horizontal: 12, vertical: 6),
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(14)),
      child: InkWell(
        borderRadius: BorderRadius.circular(14),
        onTap: () {
          Navigator.push(
            context,
            MaterialPageRoute(
              builder: (_) => DetailScreen(propertyId: property.id),
            ),
          );
        },
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.stretch,
          children: [
            Stack(
              children: [
                ClipRRect(
                  borderRadius:
                      const BorderRadius.vertical(top: Radius.circular(14)),
                  child: img.isEmpty
                      ? Container(
                          height: 180,
                          color: Colors.grey.shade200,
                          child: const Icon(Icons.home, size: 64),
                        )
                      : propertyImage(img, height: 180),
                ),
                Positioned(
                  right: 8,
                  top: 8,
                  child: Container(
                    padding:
                        const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                    decoration: BoxDecoration(
                      color: property.deal == DealType.sale
                          ? Colors.green.shade700
                          : Colors.orange.shade800,
                      borderRadius: BorderRadius.circular(20),
                    ),
                    child: Text(
                      dealLabel(property.deal),
                      style: const TextStyle(color: Colors.white, fontSize: 12),
                    ),
                  ),
                ),
                Positioned(
                  left: 8,
                  top: 8,
                  child: InkWell(
                    onTap: () => app.toggleFav(property.id),
                    child: CircleAvatar(
                      backgroundColor: Colors.white,
                      child: Icon(
                        fav ? Icons.favorite : Icons.favorite_border,
                        color: fav ? Colors.red : Colors.grey,
                      ),
                    ),
                  ),
                ),
                if (property.isUserAdded)
                  Positioned(
                    right: 8,
                    bottom: 8,
                    child: Container(
                      padding: const EdgeInsets.symmetric(
                          horizontal: 8, vertical: 3),
                      decoration: BoxDecoration(
                        color: Colors.black54,
                        borderRadius: BorderRadius.circular(12),
                      ),
                      child: const Text(
                        'آگهی من',
                        style: TextStyle(color: Colors.white, fontSize: 11),
                      ),
                    ),
                  ),
              ],
            ),
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    property.title,
                    style: const TextStyle(
                        fontWeight: FontWeight.bold, fontSize: 15),
                    maxLines: 1,
                    overflow: TextOverflow.ellipsis,
                  ),
                  const SizedBox(height: 4),
                  Row(
                    children: [
                      const Icon(Icons.location_on_outlined,
                          size: 16, color: Colors.grey),
                      Expanded(
                        child: Text(
                          '${property.city} ـ ${property.address}',
                          style: const TextStyle(
                              color: Colors.grey, fontSize: 12),
                          maxLines: 1,
                          overflow: TextOverflow.ellipsis,
                        ),
                      ),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Row(
                    children: [
                      _chip(Icons.square_foot,
                          formatAreaFa(property.area)),
                      _chip(Icons.bed_outlined,
                          '${toFaDigits(property.rooms.toString())} خوابه'),
                      _chip(Icons.category_outlined,
                          propertyTypeLabel(property.type)),
                    ],
                  ),
                  const SizedBox(height: 8),
                  Text(
                    formatPriceFa(property.price),
                    style: TextStyle(
                      color: Theme.of(context).primaryColor,
                      fontWeight: FontWeight.bold,
                      fontSize: 15,
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  Widget _chip(IconData icon, String text) {
    return Container(
      margin: const EdgeInsets.only(left: 6),
      padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
      decoration: BoxDecoration(
        color: Colors.grey.shade100,
        borderRadius: BorderRadius.circular(10),
      ),
      child: Row(
        mainAxisSize: MainAxisSize.min,
        children: [
          Icon(icon, size: 14, color: Colors.grey.shade700),
          const SizedBox(width: 4),
          Text(text, style: const TextStyle(fontSize: 11)),
        ],
      ),
    );
  }
}

```

## FILE: pubspec.yaml
```yaml
name: amlak_app
description: اپلیکیشن اندروید املاک فارسی (آفلاین/لوکال)
publish_to: 'none'
version: 1.0.0+1

environment:
  sdk: '>=3.2.0 <4.0.0'

dependencies:
  flutter:
    sdk: flutter
  flutter_localizations:
    sdk: flutter
  provider: ^6.1.2
  shared_preferences: ^2.3.2
  image_picker: ^1.1.2
  flutter_map: ^6.1.0
  latlong2: ^0.9.1
  url_launcher: ^6.3.1
  intl: ^0.19.0

dev_dependencies:
  flutter_test:
    sdk: flutter
  flutter_lints: ^4.0.0

flutter:
  uses-material-design: true

```
